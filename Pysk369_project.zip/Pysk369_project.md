```python
Fold_change = 2
print(Fold_change)
```

    2
    


```python
Fold_change = 4 + 4
print("Fold_change")
```

    Fold_change
    


```python
KO_change = 4
print(KO_change)
```

    4
    


```python
ratio_fold = Fold_change / KO_change
print('ratio_fold')
```

    ratio_fold
    


```python
type(Fold_change)
```




    int




```python
type(KO_change)
```




    int




```python
type(ratio_fold)
```




    float




```python
print(4/2)
```

    2.0
    


```python
print(2/4)
```

    0.5
    


```python
print (2*4)
```

    8
    


```python
print(2+4)
```

    6
    


```python
WT_miRNA320a = 5.28
KO_miRNA320a = 26.4
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a - KO_miRNA320a * 100
print("fold difference = " , Difference, "?")
```

    fold difference =  -2634.72 ?
    


```python
WT_miRNA320a = 26.4
KO_miRNA320a = 5.28
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a / KO_miRNA320a * 100
print("fold difference = " , Difference, "?")
```

    fold difference =  499.9999999999999 ?
    


```python
WT_miRNA320a = 5.28
KO_miRNA320a = 26.4
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a / KO_miRNA320a * 100
print("fold difference = " , Difference, "?")
```

    fold difference =  20.0 ?
    


```python
WT_miRNA320a = 5.28
KO_miRNA320a = 26.4
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a - KO_miRNA320a / 100
print("fold difference = " , Difference, "?")
```

    fold difference =  5.016 ?
    


```python
WT_miRNA320a = 5.28
KO_miRNA320a = 26.4
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a + KO_miRNA320a * 100
print("fold difference = " , Difference, "?")
```

    fold difference =  2645.28 ?
    


```python
WT_miRNA320a = 5.28
KO_miRNA320a = 26.4
# HOW KO large than WT, when comparing them?
Difference = WT_miRNA320a + KO_miRNA320a / 100
print("fold difference = " , Difference, "?")
```

    fold difference =  5.5440000000000005 ?
    


```python
print(min(18, 6, 498, 4, 53, 5, 4, 165, 1, 77, 11, 4, 461, 5, 143, 87, 6, 16, 2, 17, 29, 14, 13, 11, 70, 73, 19, 2548, 578))
print(max(18, 6, 498, 4, 53, 5, 4, 165, 1, 77, 11, 4, 461, 5, 143, 87, 6, 16, 2, 17, 29, 14, 13, 11, 70, 73, 19, 2548, 578))
```

    1
    2548
    


```python
print(abs(32))
```

    32
    


```python
list(range(12))
```




    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]




```python
nums = range(16)
print(type(nums))
```

    <class 'range'>
    


```python
range(start, stop, step)
# Create a new list of odd numbers from 1 to 31 by unpacking a range object
nums_list2 = [*range(3,32,6)]
print(nums_list2)
```

    [3, 9, 15, 21, 27]
    


```python
print(abs(-32))
```

    32
    


```python
# Convert nums to a list
nums_list = list(nums)
print(nums_list)
```

    [0, 1, 2, 3, 4, 5]
    


```python
print(float(17))
print(int(1.67))
# they can be called  on strings
print(int('2548') + 1)
```

    17.0
    1
    2549
    


```python
print(" I have learnt some basic python code from instructor John Lee_ spring biof309")
print(" great! and iniate real project")
```

     I have learnt some basic python code from instructor John Lee_ spring biof309
     great! and iniate real project
    


```python
# need to solve problem how to import list file which has miroarray and miRNAseq data( getting error)
# how they need to be lsited? 
# assign the value for Microarray_miRNA_list
MicroArray = X
# assign the value for miRNAseq__miRNA_list
miRNASEQ =  Y
# How to identify if miRNA is present in Microarray_miRNA_list as well as in miRNAseq__miRNA_list when comparing them?
if present in 'X' and 'Y' = Yes
Yes = 2
print("Yes")
if only prenet in 'X' or 'Y' = No
No = 1
print("No")


```


```python
%pwd
```




    'C:\\Users\\sukik\\project_spring_2020'




```python
import Python_project_data
```


```python
import pandas as pd
```


```python
pip install pandas
```

    Requirement already satisfied: pandas in c:\users\sukik\anaconda3\lib\site-packages (0.25.1)
    Requirement already satisfied: python-dateutil>=2.6.1 in c:\users\sukik\anaconda3\lib\site-packages (from pandas) (2.8.0)
    Requirement already satisfied: numpy>=1.13.3 in c:\users\sukik\anaconda3\lib\site-packages (from pandas) (1.16.5)
    Requirement already satisfied: pytz>=2017.2 in c:\users\sukik\anaconda3\lib\site-packages (from pandas) (2019.3)
    Requirement already satisfied: six>=1.5 in c:\users\sukik\anaconda3\lib\site-packages (from python-dateutil>=2.6.1->pandas) (1.12.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import pandas as pd
print(pd.__version__)
```

    0.25.1
    


```python
import pandas as pd
```


```python
import pandas
df1 = pandas.read_excel(open('C:\\Users\\sukik\\project_spring_2020\Python_project_data\MicroArray.xlsx','rb'))
df2 = pandas.read_excel(open('C:\\Users\\sukik\\project_spring_2020\Python_project_data\miRNASEQ.xlsx','rb'))
```


```python
df1.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>hsa-miR-103a-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>1</td>
      <td>hsa-miR-106a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>2</td>
      <td>hsa-mir-1193</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>3</td>
      <td>hsa-miR-122-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>4</td>
      <td>hsa-miR-1228-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>5</td>
      <td>hsa-mir-1231</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>6</td>
      <td>hsa-miR-1233-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>7</td>
      <td>hsa-miR-1236-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>8</td>
      <td>hsa-miR-1237-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>9</td>
      <td>hsa-miR-127-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>10</td>
      <td>hsa-miR-128-2-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>11</td>
      <td>hsa-mir-1469</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>12</td>
      <td>hsa-miR-149-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>13</td>
      <td>hsa-mir-151b</td>
      <td>0.181</td>
      <td>0.680</td>
    </tr>
    <tr>
      <td>14</td>
      <td>hsa-miR-153-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>15</td>
      <td>hsa-miR-17-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>16</td>
      <td>hsa-mir-181d</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>17</td>
      <td>hsa-miR-188-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>18</td>
      <td>hsa-miR-1908-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>19</td>
      <td>hsa-miR-1908-5p</td>
      <td>0.181</td>
      <td>0.857</td>
    </tr>
    <tr>
      <td>20</td>
      <td>hsa-miR-1915-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>21</td>
      <td>hsa-mir-196b</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>22</td>
      <td>hsa-miR-200b-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>23</td>
      <td>hsa-miR-214-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>24</td>
      <td>hsa-mir-219a-2</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>25</td>
      <td>hsa-mir-23b</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>26</td>
      <td>hsa-miR-3150a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>27</td>
      <td>hsa-mir-3158-1</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>28</td>
      <td>hsa-miR-3160-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>29</td>
      <td>hsa-miR-3162-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>30</td>
      <td>hsa-miR-3191-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>31</td>
      <td>hsa-miR-320b</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>32</td>
      <td>hsa-miR-320c</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>33</td>
      <td>hsa-miR-3620-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>34</td>
      <td>hsa-miR-3667-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>35</td>
      <td>hsa-miR-371a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>36</td>
      <td>hsa-mir-378b</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>37</td>
      <td>hsa-mir-3920</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>38</td>
      <td>hsa-mir-3935</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>39</td>
      <td>hsa-mir-3937</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>40</td>
      <td>hsa-miR-3940-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>41</td>
      <td>hsa-mir-4277</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>42</td>
      <td>hsa-mir-4281</td>
      <td>0.181</td>
      <td>0.441</td>
    </tr>
    <tr>
      <td>43</td>
      <td>hsa-mir-4293</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>44</td>
      <td>hsa-miR-4433b-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>45</td>
      <td>hsa-mir-4445</td>
      <td>0.181</td>
      <td>0.441</td>
    </tr>
    <tr>
      <td>46</td>
      <td>hsa-mir-4457</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>47</td>
      <td>hsa-mir-4467</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>48</td>
      <td>hsa-mir-4468</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>49</td>
      <td>hsa-mir-4486</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>hsa-mir-7641-2</td>
      <td>150305.575</td>
      <td>161437.228</td>
    </tr>
    <tr>
      <td>1</td>
      <td>hsa-mir-6087</td>
      <td>26902.865</td>
      <td>7579.387</td>
    </tr>
    <tr>
      <td>2</td>
      <td>hsa-mir-3908</td>
      <td>24502.782</td>
      <td>38172.292</td>
    </tr>
    <tr>
      <td>3</td>
      <td>hsa-mir-7641-1</td>
      <td>18665.989</td>
      <td>25284.196</td>
    </tr>
    <tr>
      <td>4</td>
      <td>hsa-mir-5588</td>
      <td>6443.832</td>
      <td>8614.053</td>
    </tr>
    <tr>
      <td>5</td>
      <td>hsa-mir-8086</td>
      <td>1612.500</td>
      <td>5966.385</td>
    </tr>
    <tr>
      <td>6</td>
      <td>hsa-mir-4419a</td>
      <td>1585.130</td>
      <td>2550.978</td>
    </tr>
    <tr>
      <td>7</td>
      <td>hsa-mir-320a</td>
      <td>1123.525</td>
      <td>57.885</td>
    </tr>
    <tr>
      <td>8</td>
      <td>hsa-mir-3960</td>
      <td>906.635</td>
      <td>728.539</td>
    </tr>
    <tr>
      <td>9</td>
      <td>hsa-mir-3196</td>
      <td>755.338</td>
      <td>417.496</td>
    </tr>
    <tr>
      <td>10</td>
      <td>hsa-mir-6516</td>
      <td>535.005</td>
      <td>123.662</td>
    </tr>
    <tr>
      <td>11</td>
      <td>hsa-mir-3195</td>
      <td>479.848</td>
      <td>116.260</td>
    </tr>
    <tr>
      <td>12</td>
      <td>hsa-mir-3929</td>
      <td>472.225</td>
      <td>3032.248</td>
    </tr>
    <tr>
      <td>13</td>
      <td>hsa-mir-1246</td>
      <td>416.511</td>
      <td>22.087</td>
    </tr>
    <tr>
      <td>14</td>
      <td>hsa-mir-1303</td>
      <td>362.852</td>
      <td>471.949</td>
    </tr>
    <tr>
      <td>15</td>
      <td>hsa-mir-5096</td>
      <td>336.894</td>
      <td>2161.125</td>
    </tr>
    <tr>
      <td>16</td>
      <td>hsa-mir-1343</td>
      <td>332.819</td>
      <td>114.961</td>
    </tr>
    <tr>
      <td>17</td>
      <td>hsa-mir-5095</td>
      <td>309.845</td>
      <td>1156.357</td>
    </tr>
    <tr>
      <td>18</td>
      <td>hsa-mir-1273a</td>
      <td>238.724</td>
      <td>1358.478</td>
    </tr>
    <tr>
      <td>19</td>
      <td>hsa-mir-1273e</td>
      <td>231.714</td>
      <td>1307.420</td>
    </tr>
    <tr>
      <td>20</td>
      <td>hsa-mir-3658</td>
      <td>228.582</td>
      <td>166.388</td>
    </tr>
    <tr>
      <td>21</td>
      <td>hsa-mir-3159</td>
      <td>211.676</td>
      <td>1050.282</td>
    </tr>
    <tr>
      <td>22</td>
      <td>hsa-mir-3178</td>
      <td>175.345</td>
      <td>83.517</td>
    </tr>
    <tr>
      <td>23</td>
      <td>hsa-mir-1273f</td>
      <td>159.778</td>
      <td>956.453</td>
    </tr>
    <tr>
      <td>24</td>
      <td>hsa-mir-4449</td>
      <td>152.784</td>
      <td>56.230</td>
    </tr>
    <tr>
      <td>25</td>
      <td>hsa-mir-1234</td>
      <td>134.974</td>
      <td>138.676</td>
    </tr>
    <tr>
      <td>26</td>
      <td>hsa-mir-8072</td>
      <td>100.208</td>
      <td>181.103</td>
    </tr>
    <tr>
      <td>27</td>
      <td>hsa-mir-619</td>
      <td>96.423</td>
      <td>464.553</td>
    </tr>
    <tr>
      <td>28</td>
      <td>hsa-mir-1273d</td>
      <td>96.028</td>
      <td>594.262</td>
    </tr>
    <tr>
      <td>29</td>
      <td>hsa-mir-3651</td>
      <td>94.755</td>
      <td>28.396</td>
    </tr>
    <tr>
      <td>30</td>
      <td>hsa-mir-4485</td>
      <td>84.004</td>
      <td>10.412</td>
    </tr>
    <tr>
      <td>31</td>
      <td>hsa-mir-7851</td>
      <td>75.296</td>
      <td>543.617</td>
    </tr>
    <tr>
      <td>32</td>
      <td>hsa-mir-1273c</td>
      <td>72.966</td>
      <td>83.571</td>
    </tr>
    <tr>
      <td>33</td>
      <td>hsa-mir-3609</td>
      <td>71.999</td>
      <td>8.928</td>
    </tr>
    <tr>
      <td>34</td>
      <td>hsa-mir-4459</td>
      <td>71.286</td>
      <td>554.471</td>
    </tr>
    <tr>
      <td>35</td>
      <td>hsa-mir-3648-2</td>
      <td>69.375</td>
      <td>24.543</td>
    </tr>
    <tr>
      <td>36</td>
      <td>hsa-mir-7977</td>
      <td>67.083</td>
      <td>107.280</td>
    </tr>
    <tr>
      <td>37</td>
      <td>hsa-mir-3665</td>
      <td>65.840</td>
      <td>67.170</td>
    </tr>
    <tr>
      <td>38</td>
      <td>hsa-mir-4497</td>
      <td>63.305</td>
      <td>30.629</td>
    </tr>
    <tr>
      <td>39</td>
      <td>hsa-mir-1248</td>
      <td>59.763</td>
      <td>8.587</td>
    </tr>
    <tr>
      <td>40</td>
      <td>hsa-mir-3648-1</td>
      <td>59.188</td>
      <td>17.146</td>
    </tr>
    <tr>
      <td>41</td>
      <td>hsa-mir-566</td>
      <td>57.270</td>
      <td>287.982</td>
    </tr>
    <tr>
      <td>42</td>
      <td>hsa-mir-625</td>
      <td>56.293</td>
      <td>20.785</td>
    </tr>
    <tr>
      <td>43</td>
      <td>hsa-mir-4454</td>
      <td>55.147</td>
      <td>150.918</td>
    </tr>
    <tr>
      <td>44</td>
      <td>hsa-mir-1285-1</td>
      <td>51.194</td>
      <td>303.326</td>
    </tr>
    <tr>
      <td>45</td>
      <td>hsa-mir-1273g</td>
      <td>47.748</td>
      <td>276.377</td>
    </tr>
    <tr>
      <td>46</td>
      <td>hsa-mir-5684</td>
      <td>46.793</td>
      <td>136.107</td>
    </tr>
    <tr>
      <td>47</td>
      <td>hsa-mir-25</td>
      <td>46.793</td>
      <td>32.994</td>
    </tr>
    <tr>
      <td>48</td>
      <td>hsa-mir-3653</td>
      <td>46.793</td>
      <td>22.538</td>
    </tr>
    <tr>
      <td>49</td>
      <td>hsa-mir-4466</td>
      <td>44.756</td>
      <td>13.094</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.tail(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>78</td>
      <td>hsa-miR-548c-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>79</td>
      <td>hsa-mir-548f-3</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>80</td>
      <td>hsa-miR-548o-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>81</td>
      <td>hsa-mir-5588</td>
      <td>6443.832</td>
      <td>8614.053</td>
    </tr>
    <tr>
      <td>82</td>
      <td>hsa-miR-590-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>83</td>
      <td>hsa-mir-596</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>84</td>
      <td>hsa-mir-6068</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>85</td>
      <td>hsa-mir-6088</td>
      <td>0.181</td>
      <td>1.657</td>
    </tr>
    <tr>
      <td>86</td>
      <td>hsa-miR-6089</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>87</td>
      <td>hsa-mir-6090</td>
      <td>0.181</td>
      <td>0.680</td>
    </tr>
    <tr>
      <td>88</td>
      <td>hsa-mir-638</td>
      <td>0.181</td>
      <td>0.441</td>
    </tr>
    <tr>
      <td>89</td>
      <td>hsa-miR-6507-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>90</td>
      <td>hsa-miR-6510-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>91</td>
      <td>hsa-miR-6511b-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>92</td>
      <td>hsa-miR-670-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>93</td>
      <td>hsa-mir-6719</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>94</td>
      <td>hsa-miR-6726-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>95</td>
      <td>hsa-miR-6727-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>96</td>
      <td>hsa-miR-6749-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>97</td>
      <td>hsa-miR-6752-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>98</td>
      <td>hsa-mir-6754</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>99</td>
      <td>hsa-miR-6764-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>100</td>
      <td>hsa-miR-6765-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>101</td>
      <td>hsa-miR-6767-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>102</td>
      <td>hsa-miR-6771-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>103</td>
      <td>hsa-mir-6773</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>104</td>
      <td>hsa-miR-6779-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>105</td>
      <td>hsa-miR-6786-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>106</td>
      <td>hsa-miR-6787-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>107</td>
      <td>hsa-miR-6790-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>108</td>
      <td>hsa-miR-6791-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>109</td>
      <td>hsa-mir-6800</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>110</td>
      <td>hsa-miR-6803-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>111</td>
      <td>hsa-miR-6809-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>112</td>
      <td>hsa-miR-6816-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>113</td>
      <td>hsa-mir-6849</td>
      <td>0.181</td>
      <td>0.441</td>
    </tr>
    <tr>
      <td>114</td>
      <td>hsa-mir-6850</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>115</td>
      <td>hsa-miR-6851-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>116</td>
      <td>hsa-miR-6864-3p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>117</td>
      <td>hsa-miR-6869-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>118</td>
      <td>hsa-miR-6879-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>119</td>
      <td>hsa-miR-6886-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>120</td>
      <td>hsa-miR-7108-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>121</td>
      <td>hsa-miR-7162-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>122</td>
      <td>hsa-mir-7641-1</td>
      <td>18665.989</td>
      <td>25284.196</td>
    </tr>
    <tr>
      <td>123</td>
      <td>hsa-mir-7641-2</td>
      <td>150305.575</td>
      <td>161437.228</td>
    </tr>
    <tr>
      <td>124</td>
      <td>hsa-mir-8062</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>125</td>
      <td>hsa-mir-885</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>126</td>
      <td>hsa-mir-892a</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
    <tr>
      <td>127</td>
      <td>hsa-miR-99a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2.tail(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>78</td>
      <td>hsa-mir-1273h</td>
      <td>12.231</td>
      <td>51.962</td>
    </tr>
    <tr>
      <td>79</td>
      <td>hsa-mir-1268a</td>
      <td>12.231</td>
      <td>26.617</td>
    </tr>
    <tr>
      <td>80</td>
      <td>hsa-let-7g</td>
      <td>11.380</td>
      <td>3.900</td>
    </tr>
    <tr>
      <td>81</td>
      <td>hsa-mir-7110</td>
      <td>10.768</td>
      <td>17.531</td>
    </tr>
    <tr>
      <td>82</td>
      <td>hsa-mir-1285-2</td>
      <td>10.684</td>
      <td>58.591</td>
    </tr>
    <tr>
      <td>83</td>
      <td>hsa-mir-629</td>
      <td>10.684</td>
      <td>4.660</td>
    </tr>
    <tr>
      <td>84</td>
      <td>hsa-mir-4508</td>
      <td>9.707</td>
      <td>1.538</td>
    </tr>
    <tr>
      <td>85</td>
      <td>hsa-mir-142</td>
      <td>9.508</td>
      <td>8.468</td>
    </tr>
    <tr>
      <td>86</td>
      <td>hsa-mir-6126</td>
      <td>9.202</td>
      <td>3.804</td>
    </tr>
    <tr>
      <td>87</td>
      <td>hsa-miR-4485-3p</td>
      <td>9.202</td>
      <td>3.616</td>
    </tr>
    <tr>
      <td>88</td>
      <td>hsa-mir-4516</td>
      <td>8.741</td>
      <td>7.086</td>
    </tr>
    <tr>
      <td>89</td>
      <td>hsa-mir-6723</td>
      <td>8.226</td>
      <td>3.792</td>
    </tr>
    <tr>
      <td>90</td>
      <td>hsa-mir-93</td>
      <td>7.547</td>
      <td>10.392</td>
    </tr>
    <tr>
      <td>91</td>
      <td>hsa-mir-663b</td>
      <td>7.304</td>
      <td>4.436</td>
    </tr>
    <tr>
      <td>92</td>
      <td>hsa-mir-6089-2</td>
      <td>7.169</td>
      <td>2.629</td>
    </tr>
    <tr>
      <td>93</td>
      <td>hsa-mir-191</td>
      <td>6.746</td>
      <td>4.660</td>
    </tr>
    <tr>
      <td>94</td>
      <td>hsa-mir-1291</td>
      <td>6.731</td>
      <td>3.199</td>
    </tr>
    <tr>
      <td>95</td>
      <td>hsa-let-7d-3p</td>
      <td>6.263</td>
      <td>3.804</td>
    </tr>
    <tr>
      <td>96</td>
      <td>hsa-let-7d</td>
      <td>6.263</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>97</td>
      <td>hsa-mir-3135b</td>
      <td>6.061</td>
      <td>92.451</td>
    </tr>
    <tr>
      <td>98</td>
      <td>hsa-miR-423-5p</td>
      <td>6.061</td>
      <td>9.320</td>
    </tr>
    <tr>
      <td>99</td>
      <td>hsa-let-7g-5p</td>
      <td>6.061</td>
      <td>1.538</td>
    </tr>
    <tr>
      <td>100</td>
      <td>hsa-mir-642a</td>
      <td>5.690</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>101</td>
      <td>hsa-mir-762</td>
      <td>5.690</td>
      <td>2.315</td>
    </tr>
    <tr>
      <td>102</td>
      <td>hsa-mir-8485</td>
      <td>5.507</td>
      <td>39.760</td>
    </tr>
    <tr>
      <td>103</td>
      <td>hsa-mir-663a</td>
      <td>5.460</td>
      <td>29.120</td>
    </tr>
    <tr>
      <td>104</td>
      <td>hsa-mir-1268b</td>
      <td>5.115</td>
      <td>34.315</td>
    </tr>
    <tr>
      <td>105</td>
      <td>hsa-mir-5689</td>
      <td>4.971</td>
      <td>18.455</td>
    </tr>
    <tr>
      <td>106</td>
      <td>hsa-let-7b-5p</td>
      <td>4.971</td>
      <td>4.660</td>
    </tr>
    <tr>
      <td>107</td>
      <td>hsa-let-7b</td>
      <td>4.971</td>
      <td>3.804</td>
    </tr>
    <tr>
      <td>108</td>
      <td>hsa-mir-186</td>
      <td>4.971</td>
      <td>3.804</td>
    </tr>
    <tr>
      <td>109</td>
      <td>hsa-miR-576-5p</td>
      <td>4.971</td>
      <td>2.990</td>
    </tr>
    <tr>
      <td>110</td>
      <td>hsa-miR-28-3p</td>
      <td>4.971</td>
      <td>1.179</td>
    </tr>
    <tr>
      <td>111</td>
      <td>hsa-let-7f-1</td>
      <td>4.971</td>
      <td>1.179</td>
    </tr>
    <tr>
      <td>112</td>
      <td>hsa-mir-4430</td>
      <td>4.810</td>
      <td>15.928</td>
    </tr>
    <tr>
      <td>113</td>
      <td>hsa-mir-6789</td>
      <td>4.810</td>
      <td>3.804</td>
    </tr>
    <tr>
      <td>114</td>
      <td>hsa-miR-3184-3p</td>
      <td>4.810</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>115</td>
      <td>hsa-mir-150</td>
      <td>4.810</td>
      <td>1.179</td>
    </tr>
    <tr>
      <td>116</td>
      <td>hsa-mir-425</td>
      <td>4.468</td>
      <td>5.624</td>
    </tr>
    <tr>
      <td>117</td>
      <td>hsa-mir-16-2</td>
      <td>4.468</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>118</td>
      <td>hsa-mir-4707</td>
      <td>3.945</td>
      <td>5.871</td>
    </tr>
    <tr>
      <td>119</td>
      <td>hsa-miR-625-5p</td>
      <td>3.945</td>
      <td>3.767</td>
    </tr>
    <tr>
      <td>120</td>
      <td>hsa-miR-181b-5p</td>
      <td>3.945</td>
      <td>2.990</td>
    </tr>
    <tr>
      <td>121</td>
      <td>hsa-mir-4741</td>
      <td>3.945</td>
      <td>2.990</td>
    </tr>
    <tr>
      <td>122</td>
      <td>hsa-mir-484</td>
      <td>3.945</td>
      <td>2.917</td>
    </tr>
    <tr>
      <td>123</td>
      <td>hsa-miR-642b-3p</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>124</td>
      <td>hsa-let-7i-5p</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>125</td>
      <td>hsa-mir-6821</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>126</td>
      <td>hsa-miR-424-5p</td>
      <td>3.945</td>
      <td>2.315</td>
    </tr>
    <tr>
      <td>127</td>
      <td>hsa-miR-6724-5p</td>
      <td>3.945</td>
      <td>1.179</td>
    </tr>
  </tbody>
</table>
</div>




```python
df1.equals(df2)
```




    False




```python
comparison_values = df1.values == df2.values
print (comparison_values)
comparison_values = df1.values == df2.values
print (comparison_values)
```

    [[False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]]
    [[False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]
     [False False False]]
    


```python
df1.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>128.000000</td>
      <td>128.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>1370.609539</td>
      <td>1526.267906</td>
    </tr>
    <tr>
      <td>std</td>
      <td>13381.515919</td>
      <td>14438.928100</td>
    </tr>
    <tr>
      <td>min</td>
      <td>0.181000</td>
      <td>0.181000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>0.181000</td>
      <td>0.181000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>0.181000</td>
      <td>0.181000</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>0.181000</td>
      <td>0.181000</td>
    </tr>
    <tr>
      <td>max</td>
      <td>150305.575000</td>
      <td>161437.228000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>128.000000</td>
      <td>128.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>1876.540523</td>
      <td>2101.082859</td>
    </tr>
    <tr>
      <td>std</td>
      <td>13708.061876</td>
      <td>14792.686838</td>
    </tr>
    <tr>
      <td>min</td>
      <td>3.945000</td>
      <td>1.179000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>6.263000</td>
      <td>3.804000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>22.993500</td>
      <td>20.426500</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>73.548500</td>
      <td>126.773250</td>
    </tr>
    <tr>
      <td>max</td>
      <td>150305.575000</td>
      <td>161437.228000</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.merge(df1, df2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW</th>
      <th>CD47_CAP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>hsa-mir-5588</td>
      <td>6443.832</td>
      <td>8614.053</td>
      <td>6443.832</td>
    </tr>
    <tr>
      <td>1</td>
      <td>hsa-mir-7641-1</td>
      <td>18665.989</td>
      <td>25284.196</td>
      <td>18665.989</td>
    </tr>
    <tr>
      <td>2</td>
      <td>hsa-mir-7641-2</td>
      <td>150305.575</td>
      <td>161437.228</td>
      <td>150305.575</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.merge(df1, df2, left_index=True, right_index=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name_x</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW _x</th>
      <th>Name_y</th>
      <th>CD47_CAP</th>
      <th>CD47_FLOW _y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>0</td>
      <td>hsa-miR-103a-3p</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-7641-2</td>
      <td>150305.575</td>
      <td>161437.228</td>
    </tr>
    <tr>
      <td>1</td>
      <td>hsa-miR-106a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-6087</td>
      <td>26902.865</td>
      <td>7579.387</td>
    </tr>
    <tr>
      <td>2</td>
      <td>hsa-mir-1193</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-3908</td>
      <td>24502.782</td>
      <td>38172.292</td>
    </tr>
    <tr>
      <td>3</td>
      <td>hsa-miR-122-5p</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-7641-1</td>
      <td>18665.989</td>
      <td>25284.196</td>
    </tr>
    <tr>
      <td>4</td>
      <td>hsa-miR-1228-5p</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-5588</td>
      <td>6443.832</td>
      <td>8614.053</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>123</td>
      <td>hsa-mir-7641-2</td>
      <td>150305.575</td>
      <td>161437.228</td>
      <td>hsa-miR-642b-3p</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>124</td>
      <td>hsa-mir-8062</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-let-7i-5p</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>125</td>
      <td>hsa-mir-885</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-mir-6821</td>
      <td>3.945</td>
      <td>2.373</td>
    </tr>
    <tr>
      <td>126</td>
      <td>hsa-mir-892a</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-miR-424-5p</td>
      <td>3.945</td>
      <td>2.315</td>
    </tr>
    <tr>
      <td>127</td>
      <td>hsa-miR-99a-5p</td>
      <td>0.181</td>
      <td>0.181</td>
      <td>hsa-miR-6724-5p</td>
      <td>3.945</td>
      <td>1.179</td>
    </tr>
  </tbody>
</table>
<p>128 rows × 6 columns</p>
</div>




```python
import pandas as pd
import pandas
df1 = pandas.read_excel(open('C:\\Users\\sukik\\project_spring_2020\Python_project_data\MicroArray.xlsx','rb'))
df2 = pandas.read_excel(open('C:\\Users\\sukik\\project_spring_2020\Python_project_data\miRNASEQ.xlsx','rb'))
```


```python
import matplotlib
print(matplotlib)
```

    <module 'matplotlib' from 'C:\\Users\\sukik\\Anaconda3\\lib\\site-packages\\matplotlib\\__init__.py'>
    


```python
%matplotlib inline
```


```python
from matplotlib import pyplot as plt
```


```python
import pandas as pd
my_series = pd.Series([8.6, 5.1, -14.0, 3.10])
print(my_series)
from matplotlib import pyplot as plt
plt.plot(my_series)
plt.show()
```

    0     8.6
    1     5.1
    2   -14.0
    3     3.1
    dtype: float64
    


![png](output_48_1.png)



```python
import pandas as pd
my_series_1 = pd.Series([4, 6, 2,10, -4, -20, -3, 40])
my_series_2 = pd.Series([14, 16, 12,10, -14, -20, -13, 40])
print(my_series_1)
from matplotlib import pyplot as plt
plt.scatter([my_series_1],[my_series_2])
plt.show()
```

    0     4
    1     6
    2     2
    3    10
    4    -4
    5   -20
    6    -3
    7    40
    dtype: int64
    


![png](output_49_1.png)



```python

```
